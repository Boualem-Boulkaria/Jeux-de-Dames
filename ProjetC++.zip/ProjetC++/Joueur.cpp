#include "Joueur.h"
int vdebug=0; 
int PROFONDEUR_MAXI=3;
Joueur::Joueur()
{
//ctor
}

void Joueur::jouer()
{
   	int leCoupJouer=0;     //int leCoupJouer les coordonees rentre par l'humain ou l'IA que nous allons decripter en 4 valeur entier , id , jd , ia, ja,
	int resultatDuCoup=0;  //resultatDuCoup 	nous dit si le joueur a bouger ou manger une piece
	int id,jd;
	int ia,ja;
	int affiche;
	
   	while(resultatDuCoup == 0 )
   	{
   		cout<<"vous etes un joueur : "<<this->typeJoueur<<endl;
   		if(this->typeJoueur=='h' ) // h pour humain ( pour Le joueur humain)
   		{
   			affiche=1;// ici on affiche les commentaires
   			leCoupJouer=this->joueurHumain(); //je met la valeur de joueurHumain dans lecoupjouer

   		}
   		if(this->typeJoueur=='r') // r pour robot ( pour Le joueur IA)
   		{
   			affiche=0;// ici on affiche pas les commentaires
   			leCoupJouer=this->joueurIA(); //je met la valeur de joueurIA dans lecoupjouer

   		}
   		

   		if(leCoupJouer==0) return; // si leCoupJouer==0 alors on a une partie nulle donc  on s'arrete la

   		id = leCoupJouer / 1000;//int id coordonnee du pion qu'on veut deplacer  (les abscisses)
   		  leCoupJouer = leCoupJouer - (id * 1000);
   		jd = leCoupJouer / 100; //int jd coordonnee du pion qu'on veut deplacer  (les ordonnees , attention
   		  leCoupJouer = leCoupJouer - (jd * 100);
   		ia = leCoupJouer / 10;  //int ia coordonnee de l'arrivee du pion (les abscisses)
   		  leCoupJouer = leCoupJouer - (ia * 10);
   		ja = leCoupJouer;       //int ja  coordonnel'origine des ordonees (le point zero) est en haut de l'axe des ordonees )de de l'arrivee du pion (les ordonnees , attention l'origine des ordonees (le point zero) est en haut de l'axe des ordonees )
   														// ---- fin

   		
   		resultatDuCoup = testerSiDeplacementPossible(id, jd, ia, ja,affiche);
   		
   		resultatDuCoup =resultatDuCoup + testerSiPrisePossible(id, jd, ia, ja,affiche);
   		


   	}
   	//resultatDuCoup==1 je me deplace
   	if(resultatDuCoup!=0)
   	{
   		
   		effectuerDeplacement(couleur,id,jd,ia,ja);
   		

   	}
}
int Joueur::joueurHumain( )
{
	int leCoupJoue;

	cout<< couleur << " : entre les coordonnees du pion a deplacer : " ;
	cin >> leCoupJoue;
	cout<< leCoupJoue << endl  ;



	return leCoupJoue ;
}
void Joueur::initialiser(Plateau *pD, char couleur, char typeJoueur,char typeDePartie)
{
	pDamier = pD;
	this->couleur=couleur;
	this->typeJoueur=typeJoueur;
	this->typeDePartie=typeDePartie;
	}

int Joueur::testerSiDeplacementPossible(int id,int  jd,int  ia,int  ja,int affiche,Plateau *damierRecursif,char lacouleur)
{
	//ce test nousfais utiliser le damier normal si on fait une partie sans IA  mais on utilisera damierRecursif si IA
	if (damierRecursif == NULL)
	{
		damierRecursif=pDamier;
	}

	if(lacouleur==' ')  lacouleur=couleur; //on test si la couleur est autre que celle par defaut



	// Les coordonees doivent être valides pour le tableau (entre 0 et 9)
	if ( (id<0 || id>9) || (jd<0 || jd>9) || (ia<0 || ia>9) || (ja<0 || ja>9) )
	{
		if (affiche) cout << "L'une des valeurs en entree est hors tableau (doit être entre 0 et 9)" << endl;
		return 0;
	}
	// L'origine doit être sur un pion, quelle que soit la couleur
	// Elle doit donc être differente de C_POINT
	if(damierRecursif->getDamier(id,jd)== C_POINT )
	{
		if (affiche) cout << "origine non valide (il n'y a pas de pion)" << endl;
		return 0;
	}
	// L'origine doit être un pion de même couleur que le joueur qui deplace
	if(damierRecursif->getDamier(id,jd)!= lacouleur )
	{
		if (affiche) cout << "AAAAA" << damierRecursif->getDamier(id,jd) << endl;

		if (affiche) cout << "origine non valide (ce n 'est pas la bonne couleur du pion)" << endl;
		return 0;
	}
	// La destination ne doit pas être sur un pion, quelle que soit la couleur
	// la cible doit donc être C_POINT
	if(damierRecursif->getDamier(ia,ja)!= C_POINT )
	{
		if (affiche) cout << "cible non valide (il y a deja un pion)" << endl;
		return 0;
	}
	// Test des listes paires ou impaires, uniquement pour la cible
	// si i paire, j doit être impaire
	// si i impaire, j doit être paire
	if (ia&1)
	{  // ici ia est impaire
	   // ja doit être paire
		if(ja&1)
		{   // ja est impaire
			// alors il y a une erreur
			if (affiche) cout << "cible non valide (case non autorisee)" << endl;
			return 0;
		}
	}
	else
	{   // ici ia est paire
        // ja doit être impaire
		if (!(ja&1))
		{
			if (affiche) cout << "cible non valide (case non autorisee)" << endl;
			return 0;
		}
	}
	// Test pour ne pas positionner (id,jd) a (ia,ja) n'importe oû
	// (attention i est l'ordonnee)
	// (attention j est l'axe des abscisse)

	//  ici on test pour les blancs qui avancent dans un sens
	if(lacouleur==C_BLANC)
	{
		if  (!  (    (((id-1)==ia)&&((jd-1)==ja)) ||  (((id-1)==ia)&&((jd+1)==ja))    )     )
		{
			if (affiche) cout << "il faut deplacer devant le pion blanc juste a gauche ou a droite" << endl;
			return 0;
		}
	}
	//  ici on test pour les noirs qui avancent dans l'autre sens
	if(lacouleur==C_NOIR)
	{
		if   (!  (    (((id+1)==ia)&&((jd-1)==ja)) ||  (((id+1)==ia)&&((jd+1)==ja))    )     )
		{
			if (affiche) cout << "il faut deplacer devant le pion noir juste a gauche ou a droite" << endl;
			return 0;
		}
	}
	return 1;
}


int Joueur::testerSiPrisePossible(int id,int  jd,int  ia,int  ja,int affiche,Plateau *damierRecursif,char lacouleur)
{
	//ce test nousfais utiliser le damier normal si on fait une partie sans IA  mais on utilisera damierRecursif si IA
	if (damierRecursif == NULL)
	{
		damierRecursif=pDamier;
	}

	if(lacouleur==' ')  lacouleur=couleur; //on test si la couleur est autre que celle par defaut

	// Les coordonees doivent être valides pour le tableau (entre 0 et 9)
	if ( (id<0 || id>9) || (jd<0 || jd>9) || (ia<0 || ia>9) || (ja<0 || ja>9) )
	{
		if (affiche) cout << "L'une des valeurs en entree est hors tableau (doit être entre 0 et 9)" << endl;
		return 0;
	}
	// L'origine doit être sur un pion, quelle que soit la couleur
	// Elle doit donc être differente de C_POINT
	if(damierRecursif->getDamier(id,jd)== C_POINT )
	{
		if (affiche) cout << "origine non valide (il n'y a pas de pion)" << endl;
		return 0;
	}
	// L'origine doit être un pion de même couleur que le joueur qui deplace
	if(damierRecursif->getDamier(id,jd)!= lacouleur )
	{

		if (affiche) cout << "origine non valide (ce n 'est pas la bonne couleur du pion)" << endl;
		return 0;
	}
	// La destination ne doit pas être sur un pion, quelle que soit la couleur
	// la cible doit donc être C_POINT
	if(damierRecursif->getDamier(ia,ja)!= C_POINT )
	{
		if (affiche) cout << "cible non valide (il y a deja un pion)" << endl;
		return 0;
	}
	// Test des listes paires ou impaires, uniquement pour la cible
	// si i paire, j doit être impaire
	// si i impaire, j doit être paire
	if (ia&1)
	{  // ici ia est impaire
	   // ja doit être paire
		if(ja&1)
		{   // ja est impaire
			// alors il y a une erreur
			if (affiche) cout << "cible non valide (case non autorisee)" << endl;
			return 0;
		}
	}
	else
	{   // ici ia est paire
        // ja doit être impaire
		if (!(ja&1))
		{
			if (affiche) cout << "cible non valide (case non autorisee)" << endl;
			return 0;
		}
	}
	// Test pour ne pas positionner (id,jd) a (ia,ja) n'importe oû
	// (attention i est pour les lignes)
	// (attention j  pour les colonnes)

	//  ici on test pour les blancs qui avancent dans un sens
	//MAIS ici, ils mangent un noir en diagonale
	if(lacouleur==C_BLANC)
	{
		if (affiche) cout << "gauche noir "<< endl ;
		if (affiche) cout << damierRecursif->getDamier(id-1,jd-1)<< endl ;
		if (affiche) cout << "ou droit noir "<< endl ;
		if (affiche) cout << damierRecursif->getDamier(id+1,jd-1)<< endl ;
		if (affiche) cout << "fin ici "<< endl ;
		if (affiche) cout << "ici id:"<<id << "ici ia:"<< ia << "ici jd:"<< jd << "ici ja:"<< ja <<endl ;

		//manger en arriére
		if  (!(    (((id-2)==ia)&&((jd-2)==ja)) ||  (((id+2)==ia)&&((jd-2)==ja)) /* debut attention (pour manger en arriere)*/ || (((id-2)==ia)&&((jd+2)==ja)) ||  (((id+2)==ia)&&((jd+2)==ja)) /* fin attention */   )     )
		{
			if (affiche) cout << "il faut deplacer devant le pion blanc juste a gauche ou a droite pour manger" << endl;
			return 0;

		}

		if (! (   (damierRecursif->getDamier(  (id+ia)/2 , (jd+ja)/2  ) == C_NOIR)   ))
		{
			if (affiche) cout << "Pour manger un pion en diagonale, il faut un pion noir !" << endl;
			return 0;
		}
	}
	//  ici on test pour les noirs qui avancent dans l'autre sens
	if(lacouleur==C_NOIR)
	{
		if (affiche) cout << "gauche blanc "<< endl ;
		if (affiche) cout << damierRecursif->getDamier(id-1,jd-1)<< endl ;
		if (affiche) cout << "ou droit blanc "<< endl ;
		if (affiche) cout << damierRecursif->getDamier(id+1,jd-1)<< endl ;
		if (affiche) cout << "fin ici "<< endl ;
		if (affiche) cout << "ici id:"<<id << "ici ia:"<< ia << "ici jd:"<< jd << "ici ja:"<< ja <<endl ;

		// attention (((id-2)==ia)&&((jd+2)==ja)) ||  (((id+2)==ia)&&((jd+2)==ja)) est pour manger en arriere
		if   (!  (    (((id-2)==ia)&&((jd+2)==ja)) ||  (((id+2)==ia)&&((jd+2)==ja))  /* debut attention  (pour manger en arriere)*/ ||  (((id-2)==ia)&&((jd-2)==ja)) ||  (((id+2)==ia)&&((jd-2)==ja))/* fin attention */  )     )
		{
			if (affiche) cout << "il faut deplacer devant le pion noir juste a gauche ou a droite" << endl;
			return 0;
		}
		if (!(     (damierRecursif->getDamier(  (id+ia)/2 , (jd+ja)/2  ) == C_BLANC)  ))
		{
			if (affiche) cout << "Pour manger un pion en diagonale, il faut un pion blanc 2 !" << endl;
			return 0;
		}

	}
	return 2;
}

int Joueur::joueurIA()
{
	int leCoupJoue;
	cout<< couleur << " : joueurIA cherche les coordonnees du pion a deplacer : "<<endl ;
	// init des variables recursives

	//
	//    pDamier est le 1er damier qu' on utilise et appres il y en aura d'autre utilise dans l'IA
	//

	initEvaluationCoup();
	iaChercherDeplacement(couleur,1,pDamier) ; // on memorise les coups a jouer et on cherche les meilleurs
	afficherEvaluationCoup(3);
	afficherEvaluationCoup(2);
	afficherEvaluationCoup(1);
	leCoupJoue=renvoyerLaMeilleurEvaluationCoup(1);
		//cout<< leCoupJoue << endl  ;
	cout<< " l'IA a cherche: "<< 	NBDeCoupTesteParIA<< " coups"<<endl;
	cout<< " l'IA a trouve : "<< 	NBDeCoupBONTesteParIA<< " coups"<<endl;

	if(NBDeCoupBONTesteParIA!=0)	cout<< " l'IA  a joue :  "<<leCoupJoue<<endl;
	else
	{   cout<<"partie nulle"<<endl;
		cout<<"FIN DE PARTIE"<<endl;
		pDamier->MettrePartieNulle();
		return 0;

   }

	return leCoupJoue;

}
void Joueur::evaluerDeplacement(int id,int  jd,int  ia,int  ja,int profondeurCourante,Plateau *damierRecursif,char lacouleur)
{
	static int LeCoupJouePremierNiveau=0;

	int coupPossible;
	

		// testerSiDeplacementPossible(int id,int jd,int ia,int ja);
		if((testerSiDeplacementPossible(id,jd,ia,ja,0,damierRecursif,lacouleur)==1)||(testerSiPrisePossible(id,jd,ia,ja,0,damierRecursif,lacouleur)==2)||(testerSiPrisePossible(id,jd,ia,ja,0,damierRecursif,lacouleur)==-2))
		{
			if (vdebug) cout << "   AAAAAA (evaluerDeplacement) voici un coup possible depart="<< id << " " << jd << " arrive=" << ia << " " << ja << " PROFONDEUR="<<profondeurCourante<<endl ;




			// Faire une copie du damier actuel
			Plateau monDamier_memo;
			monDamier_memo.initialiser_par_copie_damier(damierRecursif);

			// Faire avancer selon le coup possible
			monDamier_memo.setDamier(ia,ja,lacouleur); // je met la couleur de mon point de depart a mon point d'arrive
			monDamier_memo.setDamier(id,jd,C_POINT); // je met un point a la place de mon pion de depart
			//resultatDuCoup==2 || resultatDuCoup==-2
		   	//resultatDuCoup==2 je mange en avant
		   	//resultatDuCoup==-2 je mange en arriere
		   	if (
		   			((ia-id)==2)||
		   			((ia-id)==-2)
		   			) // ici j'efface mon  pion noir a manger et j'affiche un point
		   	{
//		   		monDamier_memo.setDamier( ((id+ia)/2),((jd+ja)/2),C_POINT,'D' );
		   	}

		   	if (vdebug)cout << "   AAAAAA0  DAMIER monDamier_memo : " << endl;
		   	if (vdebug)monDamier_memo.afficher();

			if(profondeurCourante==1)
			{
				LeCoupJouePremierNiveau=((id*1000)+(jd*100)+(ia*10)+(ja*1));
			}

			// on dertermine si le nouveau coup est gagnant
			// attention si le coups est gagnant alors on ne dois pas faire de recursivirte
		   	char CouleurGagnante=' ' ;
	   		if(monDamier_memo.testSiFinDePartie(C_BLANC,0,typeJoueur)==1)
	   		{
	   			CouleurGagnante=C_BLANC;
	   		}
	   		if(monDamier_memo.testSiFinDePartie(C_NOIR,0,typeJoueur)==1)
	   		{
	   			CouleurGagnante=C_NOIR;
	   		}

	   		// attention a partir d'ici on test la recursivirté pour chaque profondeur
	   		// sauf si on a une couleur gagnante

	   		// ici on cherche la recursivité du coup  jusqu'a PROFONDEUR_MAXI
			if(PROFONDEUR_MAXI>profondeurCourante)
		   	{

				// ICI, on n'est pas a la profondeux maximum
				// on va donc evaluer de façon recursive

				// init du stockage pour  cette profondeur, afin de calculer le MINIMAX dechaque profondeur
				initEvaluationCoup(profondeurCourante+1);

				// attention ici on cherche un nouveau deplacement uniquement s'il n'y a pas de couleur gagnante
				if(CouleurGagnante==' ')
				{
					if (vdebug)cout<<"CouleurGagnante==' ' "<<endl;
			   		if(lacouleur==C_BLANC)
			   		{
			   			if (vdebug)cout<<"ZZZZZZ1 BLANC "<<endl;
			   			iaChercherDeplacement(C_NOIR,profondeurCourante+1,&monDamier_memo) ;
			   		}
			   		if(lacouleur==C_NOIR)
			   		{
			   			if (vdebug) cout<<"ZZZZZZ1 NOIR"<<endl;
			   			iaChercherDeplacement(C_BLANC,profondeurCourante+1,&monDamier_memo) ;
			   		}

			   		// calcul du MINI/MAX uniquement s'il y a eu recursivite
			   		// --> prendre la premiere evaluation (i mini du tableau) du niveau (profondeurCourante+1)
					//     et on le stocke dans (profondeurCourante)
			   		if (stockerEvaluationCoupMINIMAX(profondeurCourante,((id*1000)+(jd*100)+(ia*10)+(ja*1)))==1)
			   		{
				   		// ici, on ne va pas plus loin, car l'evaluation ne doit être faite que avec la profondeur maximum
				   		return;
			   		}
				}
				else
				{	//ici la couleur est gagnante et la profondeur maxi n'est pas ateinte
					// Evaluer ce coup possible
					// par rapport à la couleur du joueur IA
				   	if (couleur==C_NOIR)
				   	{   // expliquation de flo : l'evaluation prend en compte les deux joueurs, on va donc jouer en fonction du joueur adverse
				   		coupPossible=2*monDamier_memo.evaluerPositionJoueur(C_NOIR)-monDamier_memo.evaluerPositionJoueur(C_BLANC);
				   	}
				   	else
				   	{
				   		coupPossible=2*monDamier_memo.evaluerPositionJoueur(C_BLANC)-monDamier_memo.evaluerPositionJoueur(C_NOIR);
				   	}



				   	//et c'est dans cette fonction que va afficher l'evaluation
				   	stockerEvaluationCoup(coupPossible,((id*1000)+(jd*100)+(ia*10)+(ja*1)),profondeurCourante,LeCoupJouePremierNiveau,lacouleur,CouleurGagnante);

				}

		   		// ici, il n'y a pas eu d'evaluation au niveau superieur, car plus aucun deplacement possible
		   		// on va stocker le coup courant juste apres

		   	}
			else
			{	//(else): si  la profondeur maxi est atteinte c 'est alors que nous alons stocker l'evaluation

				// Evaluer ce coup possible
				// par rapport à la couleur du joueur IA
			   	if (couleur==C_NOIR)
			   	{   // expliquation de flo : l'evaluation prend en compte les deux joueurs, on va donc jouer en fonction du joueur adverse
			   		coupPossible=2*monDamier_memo.evaluerPositionJoueur(C_NOIR)-monDamier_memo.evaluerPositionJoueur(C_BLANC);
			   	}
			   	else
			   	{
			   		coupPossible=2*monDamier_memo.evaluerPositionJoueur(C_BLANC)-monDamier_memo.evaluerPositionJoueur(C_NOIR);
			   	}



			   	//et c'est dans cette fonction que va afficher l'evaluation
			   	stockerEvaluationCoup(coupPossible,((id*1000)+(jd*100)+(ia*10)+(ja*1)),profondeurCourante,LeCoupJouePremierNiveau,lacouleur,CouleurGagnante);
			}
		   	// ici, ils'agit d'un coup bon teste par IA
		   	NBDeCoupBONTesteParIA++;



		}

};

void Joueur::iaChercherDeplacement(char lacouleur,int profondeurCourante,Plateau*damierRecursif) // cette fonction sert a chercher les meilleur coups
{


	// boucler sur chacune des cases du claviers
	int i,j;
	if (vdebug) cout <<"lacouleur="<<lacouleur<<" profondeurCourante = "<< profondeurCourante<<endl;
	for(i=0;i<10;i++) 	//ligne
		{
			for(j=0;j<10;j++)     //colonne
		    {
				NBDeCoupTesteParIA++;//si on passe ici c 'est qu'on a trouver un coup , on va donc faire NBDeCoupTesteParIA++;



				// pour chaque case dont on est sur la couleur du joueur
				if(damierRecursif->getDamier(i,j)==lacouleur)
				{
					//damierRecursif->afficher();
					if (vdebug) cout << lacouleur << " AAAAAA test des 6 coups possibles a partir de " << (i) << " " << (j) << " par la couleur="<<lacouleur<<" profondeurCourante = "<< profondeurCourante<<endl;

					// test des 6 combinaisons possible ( 2 deplacemet 2prises avant 2 prises arriere)

					// test des deplacements avant
					if(lacouleur==C_NOIR)
					{

						// Tester si deplacement ou prise possible, et evaluer la position si on fait la prise
						// renvoie 0 si pas possible,
						//         1 si possible, et les valeurs coupjoue et valeurcoup (donc dans cette fonctin  on modifie leCoupJoue)
						evaluerDeplacement(i,j,i+1,j+1,profondeurCourante,damierRecursif,lacouleur);
						evaluerDeplacement(i,j,i+1,j-1,profondeurCourante,damierRecursif,lacouleur);


					}
					else
					{
						evaluerDeplacement(i,j,i-1,j+1,profondeurCourante,damierRecursif,lacouleur);
						evaluerDeplacement(i,j,i-1,j-1,profondeurCourante,damierRecursif,lacouleur);

					}
					// attention les deux couleurs peuvent manger en avant ou en arriere donc c 'est pourquoi c'est des evaluations communes
					evaluerDeplacement(i,j,i-2,j-2,profondeurCourante,damierRecursif,lacouleur);
					evaluerDeplacement(i,j,i-2,j+2,profondeurCourante,damierRecursif,lacouleur);
					evaluerDeplacement(i,j,i+2,j-2,profondeurCourante,damierRecursif,lacouleur);
					evaluerDeplacement(i,j,i+2,j+2,profondeurCourante,damierRecursif,lacouleur);

					//	cout  << " AAA \n" ;
				}
		    }
		}



}


void Joueur::stockerEvaluationCoup (int ValeurCoup, int coupjoue,	int Profondeur,int CoupJouePremierNiveau ,char laCouleur,	char CouleurGagnante)
{
	// il y a  3 paves , en 1er la CouleurGagnante est celle du joueur  , en second la couleur gagnante non renseigne , en troisieme la couleur gagnante est celle de l'adversaire




	
	int i,n;


	if(laCouleur==couleur)//on test si laCouleur  est la même que la couleur que celle du joueur
	{

		for(i=0;i<CompteurDesCoupsEvalues[Profondeur];i++)
		{
			if(CouleurGagnante== couleur )  //la couleur gagnante inseree est la couleur du joueur  : 1 er pave
			{
				if(TabEvalCoup[i][Profondeur].CouleurGagnante==couleur)
				{
					//cout<<"TabEvalCoup[i][Profondeur].ValeurCoup = "<<TabEvalCoup[i][Profondeur].ValeurCoup<<" ValeurCoup = "<<ValeurCoup<<endl;
					if(TabEvalCoup[i][Profondeur].ValeurCoup<ValeurCoup)  break; // donc ce test va me servir a trier les CouleurGagnante en fonction de ValeurCoup (ordre decroissant)
				}
				else
				{

					break;// dans ce cas j'ai une couleur gagnante adverse ou un ' ' donc je decale tout

				}



			}
			else if(CouleurGagnante== ' ' )  //la couleur gagnante inseree est celle non renseignee  : 2 eme pave
			{
				if(TabEvalCoup[i][Profondeur].CouleurGagnante==' ')
				{
					//cout<<"i = "<<i<<endl;
					//cout<<"TabEvalCoup[i][Profondeur].CouleurGagnante==' '"<<endl;
					//cout<<"TabEvalCoup[i][Profondeur].ValeurCoup = "<<TabEvalCoup[i][Profondeur].ValeurCoup<<" ValeurCoup = "<<ValeurCoup<<endl;
					if(TabEvalCoup[i][Profondeur].ValeurCoup<ValeurCoup)  break; // donc ce test va me servir a trier les CouleurGagnante en fonction de ValeurCoup (ordre decroissant)
				}
				else
				{

					if (TabEvalCoup[i][Profondeur].CouleurGagnante != couleur)  break;

				}




			}
			else  //la couleur gagnante insere est celle de l'adversaire  : 3 eme pave
			{

			}

		}
	}
	else
	{
		// attention le tri sera par ordre  croissant , la premiere valeur est le MIN

			//on cherche en i la position d'insertion de la nouvelle evaluation du tableau
			for(i=0;i<CompteurDesCoupsEvalues[Profondeur];i++)
			{
				if((CouleurGagnante!= couleur)&&(CouleurGagnante!=' ') )  //la couleur gagnante inseree est la couleur de l'adversaire : 1 er pave
				{
					if((TabEvalCoup[i][Profondeur].CouleurGagnante!=couleur)&&(TabEvalCoup[i][Profondeur].CouleurGagnante!=' '))
					{
	
						if(TabEvalCoup[i][Profondeur].ValeurCoup>ValeurCoup)  break; // donc ce test va me servir a trier les CouleurGagnante en fonction de ValeurCoup (ordre decroissant)
					}
					else
					{

						break;// dans ce cas j'ai une couleur gagnante adverse ou un ' ' donc je decale tout

					}



				}
				else if(CouleurGagnante== ' ' )  //la couleur gagnante inseree est celle non renseignee  : 2 eme pave
				{
					if(TabEvalCoup[i][Profondeur].CouleurGagnante==' ')
					{
						
						
						if(TabEvalCoup[i][Profondeur].ValeurCoup>ValeurCoup)  break; // donc ce test va me servir a trier les CouleurGagnante en fonction de ValeurCoup (ordre decroissant)
					}
					else
					{

						if ((TabEvalCoup[i][Profondeur].CouleurGagnante == couleur)&&(TabEvalCoup[i][Profondeur].CouleurGagnante !=' ')) break;

					}




				}
				else  //la couleur gagnante insere est celle de l'adversaire  : 3 eme pave
				{
					// on va en fin de tableau
					// on insere que si tableau non rempli


				


				}

			}

	}

	

	for(n=(CompteurDesCoupsEvalues[Profondeur]-1);n>=i;n--)
	{
	//	cout<< " n= "<<n<<endl;
		TabEvalCoup[n+1][Profondeur].ValeurCoup=TabEvalCoup[n][Profondeur].ValeurCoup;
		TabEvalCoup[n+1][Profondeur].coupjoue=TabEvalCoup[n][Profondeur].coupjoue;
		TabEvalCoup[n+1][Profondeur].Profondeur=TabEvalCoup[n][Profondeur].Profondeur;
		TabEvalCoup[n+1][Profondeur].CoupJouePremierNiveau=TabEvalCoup[n][Profondeur].CoupJouePremierNiveau;
		TabEvalCoup[n+1][Profondeur].Couleur=TabEvalCoup[n][Profondeur].Couleur;
		TabEvalCoup[n+1][Profondeur].CouleurGagnante=TabEvalCoup[n][Profondeur].CouleurGagnante;

	}

	// insertion en i de l'evaluation passe en parametre
	TabEvalCoup[i][Profondeur].ValeurCoup=ValeurCoup;
	TabEvalCoup[i][Profondeur].coupjoue=coupjoue;
	TabEvalCoup[i][Profondeur].Profondeur=Profondeur;
	TabEvalCoup[i][Profondeur].CoupJouePremierNiveau=CoupJouePremierNiveau;
	TabEvalCoup[i][Profondeur].Couleur=laCouleur;
	TabEvalCoup[i][Profondeur].CouleurGagnante=CouleurGagnante;


	if(CompteurDesCoupsEvalues[Profondeur]<TAILLE_TABLEAU_EVALUATION)    CompteurDesCoupsEvalues[Profondeur]=CompteurDesCoupsEvalues[Profondeur]+1;

}

void Joueur::initEvaluationCoup(int Profondeur)
{
	CompteurDesCoupsEvalues[Profondeur]=0;	//CompteurDesCoupsEvalues dans le tableau
	if ( Profondeur==0 ) // Cas de l'init au lancement de IA
	{   NBDeCoupTesteParIA=0;// NBDeCoupTesteParIA en total
		NBDeCoupBONTesteParIA=0;//NBDeCoupBONTesteParIA  au total
		for (int i=1;i<12;i++) CompteurDesCoupsEvalues[i]=0;
	}
	time_t tp;       // mettre les rand en fonction du temps
	srand(time(&tp));//
}

int Joueur::renvoyerLaMeilleurEvaluationCoup (int Profondeur)
{
	//---
	// si il y a par exemple 4 (TabEvalCoup[i].ValeurCoup) qui ont la meme valeur et qui sont les meileurs je doit choisir aleatoirement  l'une des 4 valeurs
	int NBDeValPareil=1;
	int ValChoisie=0;
	int i;

	for(i=0;TabEvalCoup[i][Profondeur].ValeurCoup==TabEvalCoup[i+1][Profondeur].ValeurCoup;i++)
	{


		NBDeValPareil++;

		
	}
	ValChoisie=((rand()%NBDeValPareil));
	

	return TabEvalCoup[ValChoisie][Profondeur].CoupJouePremierNiveau;

}

void Joueur::afficherEvaluationCoup(int profondeurCourante)
{

	if (couleur==TabEvalCoup[0][profondeurCourante].Couleur)  // si couleur==TabEvalCoup[0][profondeurCourante].Couleur alors on cherche le MAX
	{


	}else
	{
	
	}
	
	int i;
	for(i=0;i<(CompteurDesCoupsEvalues[profondeurCourante]);i++)
	{
		cout<<"i= "<<i;
		cout<<" ValeurCoup= "<<TabEvalCoup[i][profondeurCourante].ValeurCoup<<" coupjoue= "<<TabEvalCoup[i][profondeurCourante].coupjoue<<" Profondeur= "<<TabEvalCoup[i][profondeurCourante].Profondeur<<" Couleur= "<<TabEvalCoup[i][profondeurCourante].Couleur<<" CouleurGagnante= "<<TabEvalCoup[i][profondeurCourante].CouleurGagnante<<" CoupJouePremierNiveau= "<<TabEvalCoup[i][profondeurCourante].CoupJouePremierNiveau<<endl;


	}
}

char Joueur::renvoyerLeTypeDeJoueur()
{

	return typeJoueur;
}

void Joueur::effectuerDeplacement(char lacouleur,int id,int jd,int ia,int ja)
{

	pDamier->setDamier(ia,ja,lacouleur); // je met la couleur de mon point de depart a mon point d'arrive
	pDamier->setDamier(id,jd,C_POINT); // (il affiche le vide)je met un point a la place de mon pion de depart
	
   	if (       ( (ia-id)==2 )
   			|| ( (ia-id)==-2)
   	   ) // ici j'efface mon  pion noir a manger et j'affiche un point
   	{
 		pDamier->setDamier( ((id+ia)/2),((jd+ja)/2),C_POINT );
   	}



}


int Joueur::stockerEvaluationCoupMINIMAX(int profondeurCourante,int coupjoue_profondeurCourante)
{



	//cout << "AAAAAA cjoueur::EvaluationCoupMINIMAX profondeurCourante="<< profondeurCourante << endl;
	//cout << "AAAAAA cjoueur::EvaluationCoupMINIMAX AFFICHAGE TABLEAU :" << endl;

	//afficherEvaluationCoup(profondeurCourante+1); a chaque stockage j'affiche

	// si le tableau profondeurCourante+1 est vide, on renvoie 2
	if (CompteurDesCoupsEvalues[profondeurCourante+1]==0)
		return 1;


	// trouver le i de la meilleure evaluation de la (profondeurCourante+1)
	int NBDeValPareil=1;
	int ValChoisie=0;
	int i;

	for(i=0;
	     (TabEvalCoup[i][profondeurCourante+1].ValeurCoup==TabEvalCoup[i+1][profondeurCourante+1].ValeurCoup)
	      && (i<CompteurDesCoupsEvalues[profondeurCourante+1]);
	   i++)
	{


		NBDeValPareil++;

		
	}
	ValChoisie=((rand()%NBDeValPareil));

	char lacouleur;
	if (TabEvalCoup[ValChoisie][profondeurCourante+1].Couleur==C_BLANC)
	{
		lacouleur=C_NOIR;
	}
	else
	{
		lacouleur=C_BLANC;
	}


	// les stocker en (profondeurCourante)
	stockerEvaluationCoup(TabEvalCoup[ValChoisie][profondeurCourante+1].ValeurCoup,
			coupjoue_profondeurCourante,
			profondeurCourante,
			TabEvalCoup[ValChoisie][profondeurCourante+1].CoupJouePremierNiveau ,
			lacouleur,
			TabEvalCoup[ValChoisie][profondeurCourante+1].CouleurGagnante);


	return 0;
}
