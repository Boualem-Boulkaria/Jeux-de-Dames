#ifndef JOUEUR_H
#define JOUEUR_H
#include "Plateau.h"
using namespace std;

extern int PROFONDEUR_MAXI;//variable pour le calcul recursif
const int TAILLE_TABLEAU_EVALUATION=200;


struct EvalCoup
{
	int ValeurCoup;
	int coupjoue;
	int ProfondeurMAX;
	int Profondeur;
	int CoupJouePremierNiveau;
	char Couleur;
	char CouleurGagnante;

};




class Joueur
{
    public:
        Joueur();

	// Methodes accesseur et mutateur
	void effectuerDeplacement(char lacouleur,int id,int jd,int ia,int ja);

	// Autres methodes
	//void initialiser() ;
	int testerSiDeplacementPossible(int id,int jd,int ia,int ja,int affiche=1,Plateau *damierRecursif=NULL,char lacouleur=' ');
	int testerSiPrisePossible(int id,int jd,int ia,int ja,int affiche=1,Plateau *damierRecursif=NULL,char lacouleur=' ');

	void jouer ();
	int joueurHumain(); //on  creer un joeur humain (qui rentre les coups )
	int joueurIA() ;     //on creer un joueur artificielle qui calcul les coups a l'avance avec fonction int iaChercherDeplacement(couleur)


	void initialiser(Plateau *pD, char couleur, char typeJoueur,char typeDePartie);
	//int testerSiDeplacementPossible(char couleur, int id, int jd, int ia, int ja );
	//int testerSiPrisePossible(char couleur, int id,int  jd,int  ia,int  ja);

	void iaChercherDeplacement(char lacouleur,int profondeurCourante,Plateau *damierRecursif); // cette fonction sert a chercher les meilleur coups

	void  evaluerDeplacement(int id,int  jd,int  ia,int  ja, int profondeurCourante,Plateau *damierRecursif,char lacouleur);

	int joueurNetwork();  //on creer un joueur Network ou reseau qui recupere un joué via le réseau par un adversaire

	// fonction de stokage de l'évaluation
	void stockerEvaluationCoup (int ValeurCoup, int coupjoue,	int Profondeur,int CoupJouePremierNiveau,	char Couleur,	char CouleurGagnante);

	void initEvaluationCoup(int Profondeur=0);

	int renvoyerLaMeilleurEvaluationCoup (int Profondeur);

	void afficherEvaluationCoup(int profondeurCourante);

	int stockerEvaluationCoupMINIMAX(int profondeurCourante,int coupjoue_profondeurCourante);

	char renvoyerLeTypeDeJoueur();



    protected:


    private:
    // c 'est ici oû on met toujours les attributs
	Plateau *pDamier;
	char typeJoueur;
	char typeDePartie; // en l (local ou en n (network = reseau)


	char couleur; // couleur du joueur

	int qualitesdescoups;
	//int id,jd;
	//int ia,ja;



	EvalCoup TabEvalCoup[TAILLE_TABLEAU_EVALUATION+1][15];

	int CompteurDesCoupsEvalues[15];

	int NBDeCoupTesteParIA; // nb de tous les coups testé par l'IA
	int NBDeCoupBONTesteParIA;// nb de coups bons testé par l'IA
};

#endif // JOUEUR_H
