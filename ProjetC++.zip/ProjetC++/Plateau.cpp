#include "Plateau.h"
#define ANSI_COLOR_RED    "\x1B[47m"
#define ANSI_COLOR_RESET   "\x1b[0m"
#define BACKWHT "\x1B[47m"
#define BACKGRAY "\e[100m"
#define FOREBLK "\e[30m"
#define FORECYN  "\x1B[36m"

Plateau::Plateau()
{
  PartieNulle=0; //ctor
}
char Plateau::getDamier(int i, int j)
{
	return tabDamier[i][j];
}
char Plateau::getEchequier(int i, int j)
{
	return tabDamier[i][j];
}
void Plateau::setDamier(int i, int j, char valeur)
{
   if((i>=0)&&(i<10)&&(j<10)&&(j>=0))	tabDamier[i][j]=valeur;
	else cout << "il y a une ereur dans setDamier, paramettre hors borne i=" << i << " j=" << j <<"\n";
}
void Plateau::setEchiquier(int i,int j,char valeur){
if((i>=0)&&(i<8)&&(j<8)&&(j>=0))	tabDamier[i][j]=valeur;
	else cout << "il y a une ereur dans setEchequier, paramettre hors borne i=" << i << " j=" << j <<"\n";}


void Plateau::initialiser()
{   int i;
	int j;

	// Mettre un '.' sur TOUTES les cases

	 for(i=0;i<10;i++)  // i ligne
	 {
	        for(j=0;j<10;j++) // j colonne
	        {
	        	tabDamier[i][j]=C_POINT;
	        }
	 }

	// Mettre un 'n' sur uniquement les cases NOIR
	 for(i=0;i<4;i++)  // i ligne
	 {
	        for(j=0;j<10;j++) // j colonne
	        {
	        	// Si i paire, on incremente tout de suite
	        	if ((i==0) ||(i==2) )
	        	{
	        		 j++;
	        	     tabDamier[i][j]=C_NOIR;
	        	}
	        	else
	        	{
	        	     tabDamier[i][j]=C_NOIR;
	        		 j++;
	        	}
	        }
	 }

	// Mettre un 'b' sur uniquement les cases BLANC
	 for(i=6;i<10;i++)  // i ligne
	 {
	        for(j=0;j<10;j++) // j colonne
	        {
	        	// Si i paire, on incremente tout de suite
	        	if ((i==6) ||(i==8) )
	        	{
	        		 j++;
	        	     tabDamier[i][j]=C_BLANC;
	        	}
	        	else
	        	{
	        	     tabDamier[i][j]=C_BLANC;
	        		 j++;
	        	}
	        }
	 }}

void Plateau::initialiserEcheq() {
	 int i=0;
	 int j;

	  for(i=0;i<8;i++)  // i ligne
	 {
	        for(j=0;j<8;j++) // j colonne
	        {
	        	tabDamier[i][j]=C_POINT;
	        }
	 }
	 while (i==0){
    tabDamier[i][0]= Tour ;
    tabDamier[i][1]=Cavalier;
    tabDamier[i][2]=Fou;
    tabDamier[i][3]= Reine;
    tabDamier[i][4]=Roi;
    tabDamier[i][5]= Fou;
    tabDamier[i][6]=Cavalier;
    tabDamier[i][7]= Tour;}


    if (i=1)
    {
    for(j=0;j<8;j++){
      tabDamier[i][j]= Pion;
    }}
    if (i=6)
    {
    for(j=0;j<8;j++){
      tabDamier[i][j]= Pion;
    }}
 if (i=7){
    tabDamier[i][0]= Tour ;
    tabDamier[i][1]=Cavalier;
    tabDamier[i][2]=Fou;
    tabDamier[i][3]= Reine;
    tabDamier[i][4]=Roi;
    tabDamier[i][5]= Fou;
    tabDamier[i][6]=Cavalier;
    tabDamier[i][7]= Tour;}


}

void Plateau::afficher()
{
	int i;
	int j;


	//afficher en tete
	cout << endl;
	cout << FORECYN  << ".......... JEUX DE DAME .......... " <<ANSI_COLOR_RESET ;
    cout << endl;
    cout << endl;
    cout << endl;


	// debut afficher liste de chiffre 0a9 en haut
	cout << " " ;

	for(i=0;i<10;i++)
	{
		cout <<"  "<<i<<"" ;
	}
	cout << endl;
	// fin

	for(i=0;i<10;i++)
	{
		//debut afficher liste de chiffre 0a9 a gauche et droite et les point
		cout<<i<<" " ;
		for(j=0;j<10;j++)
	    {
	       	// Utilisation du cout pour l'affichage Ã  l'ecran


			//cout << endl ;
	       	//test si on est en fin de parti (on doit affiché une dame sur le pion vainceur)
	       	if((i==0)&&(tabDamier[i][j]==C_BLANC))     cout << 'B'  ;
	       	else   {if((i==9)&&(tabDamier[i][j]==C_NOIR))      cout <<'N'  ;}

            if (((i%2==0)&&(j%2!=0))||((j%2==0)&&(i%2!=0)))
                     {cout << BACKGRAY <<" " ;

                       if (tabDamier[i][j]==C_NOIR)
                       {cout  <<FOREBLK <<tabDamier[i][j] ;}
                       else
                       {cout <<  tabDamier[i][j] ;}
                       cout << " "<<ANSI_COLOR_RESET;}
                    else
                       {cout <<  BACKWHT <<" ";
                        cout << tabDamier[i][j]  ;
                        cout << " "<<ANSI_COLOR_RESET;}


	    }
		cout <<   endl  ;//pour mettre ligne de chiffre a droite
		//
	}}

	void Plateau::afficherEcheq(){
	int i;
	int j;
    cout << endl;
	cout << FORECYN  << ".......... JEUX D'Echec .......... " <<ANSI_COLOR_RESET ;
    cout << endl;
    cout << endl;
    cout << endl;

	// debut afficher liste de chiffre 0a9 en haut
	cout << " " ;


	for(i=0;i<8;i++)
	{
		cout <<"  "<<i<<"" ;
	}
	cout << endl;
	// fin

	for(i=0;i<8;i++)
	{
		//debut afficher liste de chiffre 0a9 a gauche et droite et les point
		cout<<i<<" " ;

		for(j=0;j<8;j++)
	    {

	    if (((i%2==0)&&(j%2!=0))||((j%2==0)&&(i%2!=0)))
        { cout <<  BACKGRAY<<" ";
                        cout<< tabDamier[i][j]  ;
                         cout << " "<<ANSI_COLOR_RESET;}

                         else{
                      cout <<  BACKWHT <<" ";

                          cout<< FORECYN << tabDamier[i][j] ;
                           cout << " "<<ANSI_COLOR_RESET;}

                     }

		 cout <<   endl  ;}}




	// debut afficher liste de chiffre 0a9 en bas
	/*cout << "    " ;

		for(i=0;i<20;i++)
		{
			cout << "--" ;
		}*/

		//cout << "           "<<  endl;
	//fin
	//afficher nb de pion

		//cout << "il y a "<< compterPions(C_NOIR) << " pions noir" <<endl ;
		//cout << "il y a "<< compterPions(C_BLANC)<< " pions blanc" <<endl ;



//compter le nombre de pion de chaque couleur
int Plateau::compterPions(char couleur)
{
	int i,j;
	int nbcouleur=0;

	for(i=0;i<10;i++) 	//ligne
		{
			for(j=0;j<10;j++)     //colonne
		    {
				if(tabDamier[i][j]==couleur)
				{
					nbcouleur=1+nbcouleur;
				}
		    }
		}
	return nbcouleur;
}
int Plateau::evaluerPositionJoueur(char couleur)// cette fonction renvois une valeur proportionnelle aux coups favorables
{
	int i,j;
	int eval=0;

	for(i=0;i<10;i++) 	//ligne
		{
			for(j=0;j<10;j++)     //colonne
		    {
				if(tabDamier[i][j]==couleur)
				{
					if(tabDamier[i][j]==C_BLANC)
					{
						// Evaluer un damier
						//eval=(  ((10-i)*(10-i))+eval);
						eval=(  (10-i)*2 + eval);
						//eval = eval+1;

						if(i==0) // pour forcer la fin de partie (on fait une dame)
						{
							eval=(eval+10000);
						}
						//cout << "i="<<i<<" -->"<< ((1+i)*(1+i)) <<endl ;
						//cout << " ddBLANC(" <<i<< ") eval= "<<eval ;

					}
					if(tabDamier[i][j]==C_NOIR)
					{
						// Evaluer un damier
						//eval=( ((1+i)*(1+i))+eval);
						eval=( (1+i)*2 +eval);
						//eval = eval+1;

						if(i==9) // pour forcer la fin de partie (on fais une dame)
						{
							eval=eval+10000;
						}

						//cout << "i="<<i<<" -->"<< ((1+i)*(1+i)) <<endl ;
						//cout << " ddNOIR(" <<i<< ") eval= "<<eval ;
					}


				}


		    }
		}
	//cout << " dddddddd eval= "<<eval << endl;
	return eval;
}
void Plateau::chargerDisposition(string fichier)
{

	cout<<"je suis dans chargerDisposition"<<endl;
	// Variables locales
	char contenuCase;
	int i, j, compteur;

	//char damier[100]="damier.txt";

	// Ouverture du fichier passe en parametres en lecture seule
	ifstream fin(fichier.c_str(), ios::in);

	// Initialisation du compteur
	compteur = 0;

	//contenuCase='.';
	//cout<<"contenuCase="<<contenuCase<<endl;
	// Boucle de lecture
	while (fin.get(contenuCase))
	{
		//cout<<"je suis dans le while"<<endl;

		if (contenuCase != '\n')
		{
			i = compteur / 10;
			j = compteur % 10;
			tabDamier[i][j] = contenuCase;
			cout<<"tabDamier[" << i << "][" << j<<"]=" << tabDamier[i][j]<<endl;
			compteur++;
		}else
		{
			cout<<"fin de ligne"<<endl;
		}
	}

	// Fermeture du fichier
	fin.close();
	//cout<<"fin de je suis dans chargerDisposition"<<endl;
}
int Plateau::initialiser_par_copie_damier(Plateau * pDamier) // cette fonction  va copier le damier actuel  afin d'en faire un nouveau qui servira de test
{
	int i,j;

	for(i=0;i<10;i++) 	//ligne
		{
			for(j=0;j<10;j++)     //colonne
		    {
				tabDamier[i][j]=pDamier->getDamier(i,j);
		    }
		}
	return 0;


}
 int Plateau::testSiFinDePartie(char couleur,int affiche,char typeJoueur)
{
	if (PartieNulle==1) return 1;

	int i,j;
	int aleatoir=rand()%22;
	int aleatoir2=rand()%22;
	if(couleur==C_BLANC)
	{
		i=0;
		for(j=0;j<10;j++)     //colonne
	    {
						//tabDamier[i][j]=getDamier(i,j);

			if(tabDamier[i][j]==C_BLANC)
			{
				//tabDamier[i][j]='B';
				if (affiche) cout<<" joueur blanc a gagne" << endl ;
				if((affiche)&&(typeJoueur=='r'))
				{
					if(aleatoir==1||aleatoir2==1)cout<<"c 'etait trop facile on recommence ? "<<endl;
					if(aleatoir==2||aleatoir2==2)cout<<"VOS NEURONES NE POURRONT$JAMAIS RIEN CONTRE MON CPU"<<endl;
					if(aleatoir==3||aleatoir2==3)cout<<"JE COMPTE ECRIRE UN LIVRE:$FLORIAN BBUNET vous explique$les bases des dames¯$IL FAUDRA QUE VOUS LE LISIE ? "<<endl;
					if(aleatoir==4||aleatoir2==4)cout<<"MAIS NE VOUS FAITES PAS D'ILLUSION$VOUS ETES FICHU "<<endl;
					if(aleatoir==5||aleatoir2==5)cout<<"IL N'Y A PAS DE HONTE A ABANDONNER...$QUAND ON EST UN HUMAIN "<<endl;
					if(aleatoir==6||aleatoir2==6)cout<<"A VOTRE PLACE,JE ME PLAINDRAIS$AUPRES DES CONCEPTEURS DE MON CPU"<<endl;
					if(aleatoir==7||aleatoir2==7)cout<<"A FORCE DE VOUS COTOYER$J'AI PEUR DE REGRESSER"<<endl;
					if(aleatoir==8||aleatoir2==8)cout<<"DISONS QUE VOUS AVEZ UNE$GRANDE MARGE DE PROGRESSION"<<endl;
					if(aleatoir==9||aleatoir2==9)cout<<"JE CONNAIS UN JEU AVEC$DES CROIX ET DES RONDS...$ET PUIS NON,C'EST TROP$DIFFICILE POUR VOUS"<<endl;
					if(aleatoir==10||aleatoir2==10)cout<<"LAISSEZ TOMBER LES ECHECS,$ALLEZ PLUTOT FAIRE DES COLLAGES$AVEC DES ALLUMETTES "<<endl;
					if(aleatoir==11||aleatoir2==11)cout<<"VENI,VIDI,VICI COMME DISAIT JULES "<<endl;
					if(aleatoir==12||aleatoir2==12)cout<<"VAE VICTIS ! "<<endl;
					if(aleatoir==13||aleatoir2==13)cout<<"ABYSSUS ABYSSUM INVOCAT"<<endl;
		//---------------------remonte la pente
					if(aleatoir==14||aleatoir2==14)cout<<"CA FAIT TROP LONGTEMPS QUE$JE VOUS LAISSE GAGNER "<<endl;
					if(aleatoir==15||aleatoir2==15)cout<<"VOUS MANQUEZ DE CONCENTRATION"<<endl;
					if(aleatoir==16||aleatoir2==16)cout<<"REFLECHISSEZ AU LIEU DE$JOUER N'IMPORTE QUOI "<<endl;
					if(aleatoir==17||aleatoir2==17)cout<<"CE QUI EST BIEN AVEC VOUS,$C'EST QU'IL SUFFIT D'ATTENDRE$QUE VOUS VOUS PLANTIEZ"<<endl;
					if(aleatoir==18||aleatoir2==18)cout<<"®ERRARE HUMANUM EST"<<endl;
					if(aleatoir==19||aleatoir2==19)cout<<"VOUS ETES VRAIMENT TROP$FACILE A BATTRE "<<endl;
					if(aleatoir==20||aleatoir2==20)cout<<"FLUCTUAT NEC MERGITUR"<<endl;
					if(aleatoir==21||aleatoir2==21)cout<<"c 'etait trop difficile on recommence ? "<<endl;
					if(aleatoir==22||aleatoir2==22)cout<<"c 'etait trop difficile on recommence ? "<<endl;
				}
				return 1;
			}
	    }
	}
	if(couleur==C_NOIR)
	{
		i=9;
		for(j=0;j<10;j++)     //colonne
		 {
					//	tabDamier[i][j]=getDamier(i,j);

			if(tabDamier[i][j]==C_NOIR)
			{
				//tabDamier[i][j]='N';
if (affiche) cout<<" joueur noir a gagne" << endl ;
if((affiche)&&(typeJoueur=='r'))
{
if(aleatoir==1||aleatoir2==1)cout<<"c 'etait trop facile on recommence ? "<<endl;
if(aleatoir==2||aleatoir2==2)cout<<"VOS NEURONES NE POURRONT$JAMAIS RIEN CONTRE MON CPU"<<endl;
if(aleatoir==3||aleatoir2==3)cout<<"JE COMPTE ECRIRE UN LIVRE:$FLORIAN BBUNET vous explique$les bases des dames¯$IL FAUDRA QUE VOUS LE LISIE ? "<<endl;
if(aleatoir==4||aleatoir2==4)cout<<"MAIS NE VOUS FAITES PAS D'ILLUSION$VOUS ETES FICHU "<<endl;
if(aleatoir==5||aleatoir2==5)cout<<"IL N'Y A PAS DE HONTE A ABANDONNER...$QUAND ON EST UN HUMAIN "<<endl;
if(aleatoir==6||aleatoir2==6)cout<<"A VOTRE PLACE,JE ME PLAINDRAIS$AUPRES DES CONCEPTEURS DE MON CPU"<<endl;
if(aleatoir==7||aleatoir2==7)cout<<"A FORCE DE VOUS COTOYER$J'AI PEUR DE REGRESSER"<<endl;
if(aleatoir==8||aleatoir2==8)cout<<"DISONS QUE VOUS AVEZ UNE$GRANDE MARGE DE PROGRESSION"<<endl;
if(aleatoir==9||aleatoir2==9)cout<<"JE CONNAIS UN JEU AVEC$DES CROIX ET DES RONDS...$ET PUIS NON,C'EST TROP$DIFFICILE POUR VOUS"<<endl;
if(aleatoir==10||aleatoir2==10)cout<<"LAISSEZ TOMBER LES ECHECS,$ALLEZ PLUTOT FAIRE DES COLLAGES$AVEC DES ALLUMETTES "<<endl;
if(aleatoir==11||aleatoir2==11)cout<<"VENI,VIDI,VICI COMME DISAIT JULES "<<endl;
if(aleatoir==12||aleatoir2==12)cout<<"VAE VICTIS ! "<<endl;
if(aleatoir==13||aleatoir2==13)cout<<"ABYSSUS ABYSSUM INVOCAT"<<endl;
		//---------------------remonte la pente
if(aleatoir==14||aleatoir2==14)cout<<"CA FAIT TROP LONGTEMPS QUE$JE VOUS LAISSE GAGNER "<<endl;
if(aleatoir==15||aleatoir2==15)cout<<"VOUS MANQUEZ DE CONCENTRATION"<<endl;
if(aleatoir==16||aleatoir2==16)cout<<"REFLECHISSEZ AU LIEU DE$JOUER N'IMPORTE QUOI "<<endl;
if(aleatoir==17||aleatoir2==17)cout<<"CE QUI EST BIEN AVEC VOUS,$C'EST QU'IL SUFFIT D'ATTENDRE$QUE VOUS VOUS PLANTIEZ"<<endl;
if(aleatoir==18||aleatoir2==18)cout<<"®ERRARE HUMANUM EST"<<endl;
if(aleatoir==19||aleatoir2==19)cout<<"VOUS ETES VRAIMENT TROP$FACILE A BATTRE "<<endl;
if(aleatoir==20||aleatoir2==20)cout<<"FLUCTUAT NEC MERGITUR"<<endl;
if(aleatoir==21||aleatoir2==21)cout<<"c'etait trop difficile on recommence ? "<<endl;
if(aleatoir==22||aleatoir2==22)cout<<"c 'etait trop difficile on recommence ? "<<endl;

				}
				return 1;
			}
		 }
	}
	return 0;
}

void Plateau::MettrePartieNulle() // cette fonction positionera a 1 la variable PartieNulle
{
	PartieNulle=1;
}


	

