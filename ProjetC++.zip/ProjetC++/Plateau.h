#ifndef PLATEAU_H
#define PLATEAU_H

// Inclusions des librairies
#include <iostream>
#include <string>
#include <fstream> // librairie utile pour chargerDisposition(string fichier)
#define tailleMax 120
using namespace std;

const char C_BLANC  = 'B'; //la lettre 'b' symbolise les pions blanc
const char C_NOIR   = 'N'; //la lettre 'n' symbolise les pions noir
const char C_POINT  = ' ';

const char Roi ='R';
const char Reine ='Q';
const char Tour='T';
const char Cavalier='C';
const char Fou='F';
const char Pion ='P';



class Plateau
{
    public:
        Plateau();
        void initialiser();
        void afficher();
        void setDamier(int i,int j,char valeur);
        void setEchiquier(int i,int j,char valeur);
        void afficherEcheq();
        void initialiserEcheq();
        int compterPions(char couleur);
        char getDamier(int i, int j);
        char getEchequier(int i,int j);
        int evaluerPositionJoueur(char coleur);
        void chargerDisposition(string fichier);
        int initialiser_par_copie_damier(Plateau *pDamier);
        int testSiFinDePartie(char couleur,int affiche,char typeJoueur);
        void MettrePartieNulle();
    protected:

    private:
        char type;
        int PartieNulle;
        char tabDamier[tailleMax][tailleMax];

};

#endif // PLATEAU_H

