#include <iostream>
#include "Plateau.h"
#include "Joueur.h"
using namespace std;

int main()
{
    cout << "  ***** BIENVENUE AU JEU DE PLATEAU *****  " <<endl;
    cout <<"******* selecionne votre jeu ******"<<endl;
    cout <<"  1- jeu de dame  "<<endl;
    cout <<"  2- jeu d'echec   "<<endl;
    cout <<"ENTREZ VOTRE CHOIX : ";
    int choix=99;
    int  choixJeu;
    cin>> choixJeu;
    switch (choixJeu) {
    case 1 :{

    Plateau p;
    p.initialiser();
    p.afficher();
    Joueur joueur_Blanc;  // on crée un joueur blanc
	Joueur joueur_Noir;
	while( (choix<0)||(choix>6))
	{
		cout <<"  <  ----------------- JEUX DE DAME ------------------- > "<<endl;
		cout <<"  < -- humain -- >"<<endl;
		cout <<"  < -- ROBOT -- >"<<endl;
		cout <<"  0  Choisir la difficultée(pronfondeur actuelle= "<<PROFONDEUR_MAXI<<")"<<endl;
		//cout <<"  2  chargerDisposition(damier.txt)  "<<endl;
		cout <<"  1 joueur blanc contre IA"<<endl;
		cout <<"  2 joueur noir contre IA"<<endl;
		cout <<"  3 Tester l'IA"<<endl;
		//cout <<"  6 Tester le stockage des meilleur coup possible pour l'IA"<<endl;
		cout <<"ENTREZ VOTRE CHOIX : ";
		char choix2[10];
		cin >> choix2;
		cout<<"aaaachoix2 = "<<choix2<<endl;
		choix=atoi(choix2);
		cout<<"aaaachoix = "<<choix<<endl;
		switch (choix)
		{
		case 0:do
			{
				cout<< "entre la difficulté (entre 1 et 30 que tu veux : ";
				char PROFONDEUR_MAXI_char[10];
				cin>>PROFONDEUR_MAXI_char;
				PROFONDEUR_MAXI=atoi(PROFONDEUR_MAXI_char);
				//if (PROFONDEUR_MAXI<1)  cout<<"        PAs  de chance"<<endl;

			}while ((PROFONDEUR_MAXI<1||PROFONDEUR_MAXI>30)) ;
			cout<<"        Bonne chance"<<endl;
			choix=99;
		case 1:
			joueur_Blanc.initialiser(&p, C_BLANC,'h','l'); // c'est ici oû on initialise la couleur  et le type h comme humain et partie en local
				joueur_Noir.initialiser(&p, C_NOIR,'r','l'); // c'est ici oû on initialise la couleur  et le type h comme humain et partie en local
				break;
		case 2:
				joueur_Blanc.initialiser(&p,C_BLANC,'r','l'); // c'est ici oû on initialise la couleur  et le type h comme humain et partie en local
				joueur_Noir.initialiser(&p,C_NOIR,'h','l');   // c'est ici oû on initialise la couleur  et le type h comme humain et partie en local
        case 3:
            //recevoir un message
				{
					int ret;
					joueur_Blanc.initialiser(&p,C_BLANC,'h','l'); // c'est ici oû on initialise la couleur  et le type h comme humain et partie en local
					joueur_Noir.initialiser(&p,C_NOIR,'h','l'); // c'est ici oû on initialise la couleur  et le type h comme humain et partie en local
					p.afficher();
					joueur_Blanc.initEvaluationCoup();


					joueur_Blanc.iaChercherDeplacement(C_BLANC,1/*int profondeurCourante*/,&p/*CDamier*damierRecursif*/);


                ret=joueur_Blanc.renvoyerLaMeilleurEvaluationCoup(1);
					joueur_Blanc.afficherEvaluationCoup(1);
					cout<<"le meilleur coup est : "<<ret<<endl;
					ret=joueur_Blanc.renvoyerLaMeilleurEvaluationCoup(2);
					joueur_Blanc.afficherEvaluationCoup(2);
					cout<<"le meilleur coup est : "<<ret<<endl;
				}


					return 0;
				break;
        default :

				cout <<"tu n'as pas saisi la bonne valeur "<<endl;
				cout<<"choix = "<<choix<<endl;
				choix=99;
				}}
    p.afficher();  // on la initaliser plus haut
	for(;;)
	{
		joueur_Blanc.jouer();
		p.afficher();
		if (p.testSiFinDePartie(C_BLANC,1,joueur_Blanc.renvoyerLeTypeDeJoueur())==1) 	break;


		joueur_Noir.jouer();
		p.afficher();
		if (p.testSiFinDePartie(C_NOIR,1,joueur_Noir.renvoyerLeTypeDeJoueur())==1) 		break;
	} break;}
	case 2:
	{
	Plateau p;
	p.initialiserEcheq();
    p.afficherEcheq();


	break;}
	default :

				cout <<"tu n'as pas saisi la bonne valeur "<<endl;
				cout<<"choix = "<<choixJeu<<endl;
				choixJeu=99;
				}
    return 0;
}
